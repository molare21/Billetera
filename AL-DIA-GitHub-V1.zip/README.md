# AL DÍA

Tu billetera, al día.

Web app móvil de diario financiero personal en español.

## V1
- Registro diario de ingresos y gastos
- Balance de hoy
- Movimientos del día
- Campañas por cobrar y estados de pago
- Gastos fijos e ingresos fijos
- Datos guardados localmente en el navegador
- Sin login, bancos, IA ni backend

## Publicación
La web es estática. El archivo de entrada es `index.html`.
